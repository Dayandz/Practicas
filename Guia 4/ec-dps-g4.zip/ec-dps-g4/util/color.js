export default{
  PRIMARY_COLOR:'#2a474b',
  PRIMARY_COLOR_DARK :'#162230',
}