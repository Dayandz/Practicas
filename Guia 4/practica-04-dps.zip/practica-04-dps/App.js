import React, {useState,useEffect} from 'react';
import { Text, View, StyleSheet, SafeAreaView, StatusBar, Button } from 'react-native';
import colors from './utils/color.js';
import Form from './components/Forms';
import Footer from './components/Footer';
import Result from './components/Results';

export default function App() {
  const[capital, setCapital] = useState(null);
  const [interest, setInterest] = useState(null);
  const [month, setMonth] = useState(null);
   const [total, setTotal] = useState(null);
 const [errorMessage, setErrorMessage] = useState('');
  useEffect(() => {
   if (capital && interest && month) calculate();
   else reset();
 }, [capital, interest, month]);
 const calculate = () => {reset();
 if (!capital) {
 setErrorMessage('Añade la cantidad que quieres solicitar');
 } else if (!interest) {
 setErrorMessage('Añade el interes del prestamos');
 } else if (!month) {
 setErrorMessage('Seleccióna los meses a pagar');
 } else {
 const i = interest / 100;
 const fee = capital / ((1 - Math.pow(i + 1, -month)) / i);
 setTotal({
 monthlyFee: fee.toFixed(2).replace('.', ','),
 totalPayable: (fee * month).toFixed(2).replace('.', ','),
 });
 }
 };
 const reset = () => {
 setErrorMessage('');
 setTotal(null);
 };
  return (
    <>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={styles.Header}>
        <Text style={styles.HeadApp} > Cotizador de prestamos</Text>
        <Form
          setCapital={setCapital}
          setInterest={setInterest}
          setMonth={setMonth}
          />
      </SafeAreaView>
      <Result
        capital={capital}
        interest={interest}
        months={month}
        total={total}
        errorMessage={errorMessage}
        />
       <Footer></Footer>
    </>
  );
}

const styles = StyleSheet.create({
  Header: {
    backgroundColor: colors.PRIMARY_COLOR,
    height: 250,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    alignItems: 'center',
  },
  HeadApp: {
    marginTop: 15,
    fontSize: 25,
    fontWeight: 'bold',
    color: '#fff',
  },
});
