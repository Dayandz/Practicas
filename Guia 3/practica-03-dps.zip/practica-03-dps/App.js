import * as React from 'react';
import { Text, View, StyleSheet, SafeAreaView, StatusBar, FlatList, Image } from 'react-native';
import {AppRegistry} from "react-native";

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

const DATA =[
  {id: '1', title: 'toyota', src:require('./src/img/toyota.png'),},
  {id: '2', title: 'mazda', src:require('./src/img/mazda.png'),},
  {id: '3', title: 'mitsubishi',src:require('./src/img/mitsubishi.png')},
];
 const Item=({title,img})=>(
   <View style={styles.item}>
   <Text style={styles.title}> {title}</Text>
   <Image style={styles.img} source={img}/>
   </View>
 );
//const App=()=>{
   const renderItem=({item})=> (
   <Item title={item.title} img={item.src}/>
 ); 
//}

export default function App() {
 return(
<SafeAreaView style={styles.container}>
<FlatList 
data={DATA}
renderItem={renderItem}
keyExtractor={item => item.id}/>
</SafeAreaView>
 );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
   marginTop: StatusBar.currentHeight ||0,
  },
  item: {
    backgroundColor: '#f9c2ff', padding: 20, marginVertical:8, marginHorizontal:16,
    alignItems: 'center'
  },
  title:{
    fontSize: 32,
  },
  img:{width:200, height:125, borderwidth:2, boerderColor:'#d35647', resizeMode:'contain', margin:8
  }
});

AppRegistry.registerComponent("cars", ()=> App);